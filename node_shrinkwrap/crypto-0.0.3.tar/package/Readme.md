# crypto #

JavaScript implementations of standard and secure cryptographic algorithms.

## Install ##

    npm install crypto

