module.exports.all = require('./data/all').properties;
