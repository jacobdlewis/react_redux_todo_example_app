export default class ExtendableError extends Error { }
