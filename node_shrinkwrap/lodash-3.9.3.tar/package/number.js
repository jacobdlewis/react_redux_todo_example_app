module.exports = {
  'inRange': require('./number/inRange'),
  'random': require('./number/random')
};
