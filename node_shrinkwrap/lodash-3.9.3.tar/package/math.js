module.exports = {
  'add': require('./math/add'),
  'max': require('./math/max'),
  'min': require('./math/min'),
  'sum': require('./math/sum')
};
