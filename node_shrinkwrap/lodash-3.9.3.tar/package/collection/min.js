module.exports = require('../math/min');
