module.exports = require('./reduceRight');
