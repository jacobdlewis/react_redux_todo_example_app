// This file is copied to the root of the project to allow
export { reduxReactRouter, match } from './lib/server';
