// This file is copied to the root of the project to allow
'use strict';

exports.__esModule = true;

var _libServer = require('./lib/server');

exports.reduxReactRouter = _libServer.reduxReactRouter;
exports.match = _libServer.match;