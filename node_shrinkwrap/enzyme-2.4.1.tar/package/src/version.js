import React from 'react';
export const VERSION = React.version;
export const REACT013 = VERSION.slice(0, 4) === '0.13';
export const REACT014 = VERSION.slice(0, 4) === '0.14';
export const REACT15 = VERSION.slice(0, 3) === '15.';
