# selector

A Selector in enzyme is similar to a CSS selector, but can be a number of other things as well in
order to easily specify a criteria by which you want to find nodes in a enzyme wrapper. See the
Selector page for more information.

# wrapper

A wrapper refers to the enzyme wrapper class that provides the API.


# predicate

A function that returns true or false
