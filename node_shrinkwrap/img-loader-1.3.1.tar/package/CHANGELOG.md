# Changelog

## 1.3.1

Updated dependencies

## 1.3.0

Support `?config=otherConfig` to specify advanced options

## 1.2.2

Make sure that the webpack callback is only called once

## 1.2.1

Updated dependencies

## 1.2.0

New: Allow using pngquant plugin via advanced options

Match default `optimizationLevel` 2 in plugin in this loader's defaults

## 1.1.0

New: Allow options in an `imagemin` property on the webpack config
