## 0.14.0
* fixed parsing of semicolon after mixin without body

## 0.13.0
* set the default stringifier for Rule

## 0.3.0
* Merged in webschik's changes
* cleanup of various files (license, readme, gulp file)
* added a number of new tests to capture integration failures
* resolved remaining integration failures
* further linting cleanup (eslint strict)

## 0.2.0
* Cleanup of source and build files (eslint standards)
* fixing issue with @ inside of a string in parens
* new dist folder for npm with minified source files

## 0.1.3
* Fix ES2015 module export.

## 0.1.2
* Fix interpolation inside string.

## 0.1.1
* Fix `url()` parsing.

## 0.1
* Initial release.