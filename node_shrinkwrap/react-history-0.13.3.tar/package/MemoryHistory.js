'use strict';

exports.__esModule = true;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _createMemoryHistory = require('history/createMemoryHistory');

var _createMemoryHistory2 = _interopRequireDefault(_createMemoryHistory);

var _History = require('./History');

var _History2 = _interopRequireDefault(_History);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var MemoryHistory = function MemoryHistory(_ref) {
  var children = _ref.children;

  var historyOptions = _objectWithoutProperties(_ref, ['children']);

  return _react2.default.createElement(_History2.default, {
    children: children,
    createHistory: _createMemoryHistory2.default,
    historyOptions: historyOptions
  });
};

MemoryHistory.propTypes = {
  children: _react.PropTypes.func.isRequired,
  getUserConfirmation: _react.PropTypes.func,
  initialEntries: _react.PropTypes.array,
  initialIndex: _react.PropTypes.number,
  keyLength: _react.PropTypes.number
};

exports.default = MemoryHistory;