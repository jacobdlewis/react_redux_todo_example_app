'use strict';

exports.__esModule = true;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _createBrowserHistory = require('history/createBrowserHistory');

var _createBrowserHistory2 = _interopRequireDefault(_createBrowserHistory);

var _History = require('./History');

var _History2 = _interopRequireDefault(_History);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var BrowserHistory = function BrowserHistory(_ref) {
  var children = _ref.children;

  var historyOptions = _objectWithoutProperties(_ref, ['children']);

  return _react2.default.createElement(_History2.default, {
    children: children,
    createHistory: _createBrowserHistory2.default,
    historyOptions: historyOptions
  });
};

BrowserHistory.propTypes = {
  children: _react.PropTypes.func.isRequired,
  basename: _react.PropTypes.string,
  forceRefresh: _react.PropTypes.bool,
  getUserConfirmation: _react.PropTypes.func,
  keyLength: _react.PropTypes.number
};

exports.default = BrowserHistory;