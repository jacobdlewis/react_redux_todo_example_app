'use strict';

exports.__esModule = true;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _createHashHistory = require('history/createHashHistory');

var _createHashHistory2 = _interopRequireDefault(_createHashHistory);

var _History = require('./History');

var _History2 = _interopRequireDefault(_History);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var HashHistory = function HashHistory(_ref) {
  var children = _ref.children;

  var historyOptions = _objectWithoutProperties(_ref, ['children']);

  return _react2.default.createElement(_History2.default, {
    children: children,
    createHistory: _createHashHistory2.default,
    historyOptions: historyOptions
  });
};

HashHistory.propTypes = {
  children: _react.PropTypes.func.isRequired,
  basename: _react.PropTypes.string,
  getUserConfirmation: _react.PropTypes.func,
  hashType: _react.PropTypes.oneOf(['hashbang', 'noslash', 'slash'])
};

exports.default = HashHistory;