"use strict";

exports["default"] = {};
exports.__esModule = true;