"use strict";

exports["default"] = Object.prototype.hasOwnProperty;
exports.__esModule = true;