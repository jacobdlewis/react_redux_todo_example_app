﻿# whatwg-url

whatwg-url is a full implementation of the [WHATWG URL](https://url.spec.whatwg.org/) specification.

## Current State

whatwg-url is currently up to date with the URL spec up to commit [1eab2abb38](https://github.com/whatwg/url/tree/1eab2abb3806158fc7a550ac5b7deb2d6fff5602).