module.exports = 'A..D';
