# 3.0.0 - 2016-04-01

- Export as a PostCSS plugin. Now returns a [LazyResult instance](https://github.com/postcss/postcss/blob/master/docs/api.md#lazyresult-class) instead of processed css.

# 2.0.0 - 2015-09-14

- Update to PostCSS 5

# 1.0.1 - 2015-05-25

- Avoid drop-shadow spread to throw an error, and keep as-is

# 1.0.0 - 2015-01-27

- Added: upgrade to postcss v4.x
- Added: travis CI

# 0.1.5 - 2014-12-23

- Fixed: npm "No repository field" warning

# 0.1.4 - 2014

- Added: color functions support for drop-shadow filter. Now support rgb, rgba, hsl and hsla ([#3](https://github.com/iamvdo/pleeease-filters/issues/3))
- Added: upgrade to postcss v3.x

# 0.1.3 - 2014

- Fixed: charset issue

# 0.1.2 - 2014

- Added: Create SVG blur filter, even with unit-less 0

# 0.1.1 - 2014

- Changed: Don't add filters if they're already presents

# 0.1.0 - 2014

✨ Initial release
