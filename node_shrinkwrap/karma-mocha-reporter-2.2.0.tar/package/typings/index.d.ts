/// <reference path="globals/chalk/index.d.ts" />
/// <reference path="globals/karma/index.d.ts" />
