module.exports = 'a{b,c{d,e},h}x/z';
