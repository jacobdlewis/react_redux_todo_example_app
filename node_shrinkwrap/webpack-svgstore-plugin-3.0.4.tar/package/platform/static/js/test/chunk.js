'use strict';

require('./test-2.js');

webpackSvgStore('platform/static/svg/**/*.svg', '[hash].logos.svg');
