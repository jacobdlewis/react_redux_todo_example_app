'use strict';

webpackSvgStore('platform/static/svg/**/*.svg', '[hash].test.svg');
