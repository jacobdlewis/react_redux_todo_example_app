# 2.0.1 - 2016-03-15

- Fixed: whitespace are retained between color() usage.
  ([#27](https://github.com/postcss/postcss-color-function/pull/27))

# 2.0.0 - 2015-09-07

- Removed: compatibility with postcss v4.x
([#14](https://github.com/postcss/postcss-color-function/pull/14))
- Added: compatibility with postcss v5.x
([#14](https://github.com/postcss/postcss-color-function/pull/14))

# 1.3.2 - 2015-07-08

- Fixed: the plugin now do now transform all functions that match `*color(` but
only the one that are real color function call
([#12](https://github.com/postcss/postcss-color-function/pull/12))

# 1.3.1 - 2015-07-08 **YANKED**

_This was just 1.3.0._

# 1.3.0 - 2015-06-13

- Changed: upgrade to PostCSS 4.1.x

# 1.2.0 - 2015-03-12

- Added: contrast() adjuster

# 1.1.0 - 2014-11-25

- Added: Enhanced exceptions

# 1.0.0 - 2014-10-04

✨ Initial release from [postcss-color](https://github.com/postcss/postcss-color)
