module.exports = require('./lib/color')
    .use(require('./lib/HSV'))
    .use(require('./lib/HSL'));
