# 0.2.1

* Fixed: the module failing with TypeError in Node.js 0.12.

# 0.2.0

* Added: `parent` property to all nodes that are inside a container.
* Added: `colon` type of a node.

# 0.1.0

Initial release
