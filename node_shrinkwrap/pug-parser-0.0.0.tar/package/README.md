# jade-parser

The jade parser (takes an array of tokens and converts it to an abstract syntax tree)

[![Build Status](https://img.shields.io/travis/jadejs/jade-parser/master.svg)](https://travis-ci.org/jadejs/jade-parser)
[![Dependency Status](https://img.shields.io/gemnasium/jadejs/jade-parser.svg)](https://gemnasium.com/jadejs/jade-parser)
[![NPM version](https://img.shields.io/npm/v/jade-parser.svg)](https://www.npmjs.org/package/jade-parser)

## Installation

    npm install jade-parser

## License

  MIT
