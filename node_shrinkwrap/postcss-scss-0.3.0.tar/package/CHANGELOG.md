# 0.3
* Use PostCSS 5.2.

## 0.2.1
* Fix nested prop parser for prefixed pseudo.

## 0.2
* Add nested properties support (by dryoma).

## 0.1.9
* Use PostCSS 5.1.
* Add source maos to build JS files.
* Fix interpolation in `url()`.

## 0.1.8
* Fix interpolation-in-interpolation parsing.
* Fix at-rule with interpolation parsing.

## 0.1.7
* Fix inline comments with Windows new lines.

## 0.1.6
* Parse new lines according W3C CSS syntax specification.

## 0.1.5
* Fix package dependencies.

## 0.1.4
* Fix CSS syntax error position on unclosed quotes.

## 0.1.3
* Fix ES2015 module export.

## 0.1.2
* Fix interpolation inside string.

## 0.1.1
* Fix `url()` parsing.

## 0.1
* Initial release.
