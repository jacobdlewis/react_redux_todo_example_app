module.exports = require('./html-tags.json');
