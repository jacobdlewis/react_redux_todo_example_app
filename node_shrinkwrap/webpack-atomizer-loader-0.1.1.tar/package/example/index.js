// jshint ignore: start
var React = require('react');
var Application = require('./Application');

React.render(<Application />, document.body);