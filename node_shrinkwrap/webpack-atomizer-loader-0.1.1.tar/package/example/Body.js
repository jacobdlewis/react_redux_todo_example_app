// jshint ignore: start
var React = require('react');

var Body = React.createClass({
    render: function () {
        return (
            <div className=" P(10px) M(20%) Mstart(10px) Bgc(yellow)">test2</div>
        );
    }
});

module.exports = Body;