var atomLoader = require('./dist/atomicLoader.js');

module.exports = atomLoader;
