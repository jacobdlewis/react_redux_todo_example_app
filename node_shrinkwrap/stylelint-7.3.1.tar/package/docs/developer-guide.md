# Developer guide

-   [Rules](/docs/developer-guide/rules.md): Working on stylelint's rules.
-   [Plugins](/docs/developer-guide/plugins.md): Writing your own plugins.
-   [Processors](/docs/developer-guide/processors.md): Writing your own processors.
-   [Formatters](/docs/developer-guide/formatters.md): Writing your own formatters.
-   [Rule testers](/docs/developer-guide/rule-testers.md): Using and writing rule testers.
-   [Benchmarks](/docs/developer-guide/benchmarks.md): Running benchmarks on rules.
