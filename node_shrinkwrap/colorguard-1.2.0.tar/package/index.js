var colorguard = require('./lib/colorguard');

module.exports = colorguard;
