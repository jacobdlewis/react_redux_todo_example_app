#!/usr/bin/env node
var argv = require('yargs')
    .demand(2)
    .argv;
console.dir(argv)
