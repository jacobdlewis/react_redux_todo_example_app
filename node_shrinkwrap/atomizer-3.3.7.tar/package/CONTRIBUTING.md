Contributing Code to `atomizer`
---------------------------------------------

Please be sure to sign our [CLA][] before you submit pull requests or otherwise contribute to `atomizer`. This protects developers, who rely on [BSD license][].

[BSD license]: https://github.com/acss-io/atomizer/blob/master/LICENSE.md
[CLA]: https://yahoocla.herokuapp.com/
