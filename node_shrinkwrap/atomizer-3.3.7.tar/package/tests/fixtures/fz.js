module.exports = function(api) {
    api.add({
        body: { margin: '20px' }
    });
}