
1.3.0 - January 5, 2016
-----------------------
* upgrade `color` to `0.11.0`

1.2.1 - March 16, 2015
----------------------
* add coercing strings to numbers for rgba

1.2.0 - March 6, 2015
---------------------
* add `contrast` support

1.1.2 - November 27, 2014
-------------------------
* fix for nested color functions

1.1.1 - August 26, 2014
-----------------------
* support nested color functions

1.1.0 - August 12, 2014
-----------------------
* throw errors for unknown adjusters

1.0.0 - August 11, 2014
-----------------------
* add support for nested color functions
* add `whiteness` and `blackness` support

0.1.0 - December 25, 2013
-------------------------
* fix syntax errors
* add syntax error test

0.0.2 - December 16, 2013
-------------------------
* fix percentage rgba logic

0.0.1 - December 16, 2013
-------------------------
:sparkles:
