export { default as now } from './now.js';
export { default } from './date.default.js';
