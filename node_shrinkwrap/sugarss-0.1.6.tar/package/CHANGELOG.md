# Change Log

## 0.1.6
* Fix empty comments parsing.

## 0.1.5
* Put comments after declaration semicolon.
* Use PostCSS 5.1.

## 0.1.4
* Fix parsing nested properties.

## 0.1.3
* Fix source map generation.

## 0.1.2
* Fix rule/declaration selection in nested rules.

## 0.1.1
* Fix comment between declaration case.
* Add logo (by Maria Keller).

## 0.1
* Add selector pseudo-classes support.

## 0.0.1
* Initial release.
