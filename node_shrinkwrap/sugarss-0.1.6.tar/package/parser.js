'use strict';

exports.__esModule = true;

var _declaration = require('postcss/lib/declaration');

var _declaration2 = _interopRequireDefault(_declaration);

var _comment = require('postcss/lib/comment');

var _comment2 = _interopRequireDefault(_comment);

var _atRule = require('postcss/lib/at-rule');

var _atRule2 = _interopRequireDefault(_atRule);

var _rule = require('postcss/lib/rule');

var _rule2 = _interopRequireDefault(_rule);

var _root = require('postcss/lib/root');

var _root2 = _interopRequireDefault(_root);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Parser = function () {
    function Parser(input) {
        _classCallCheck(this, Parser);

        this.input = input;

        this.pos = 0;
        this.root = new _root2.default();
        this.current = this.root;
        this.spaces = '';

        this.prevIndent = undefined;
        this.step = undefined;

        this.root.source = { input: input, start: { line: 1, column: 1 } };
    }

    Parser.prototype.loop = function loop() {
        var part = void 0;
        while (this.pos < this.parts.length) {
            part = this.parts[this.pos];

            if (part.comment) {
                this.comment(part);
            } else if (part.atrule) {
                this.atrule(part);
            } else if (part.colon) {
                var next = this.nextNonComment(this.pos);

                if (next.end || next.atrule) {
                    this.decl(part);
                } else {
                    var moreIndent = next.indent.length > part.indent.length;
                    if (!moreIndent) {
                        this.decl(part);
                    } else if (moreIndent && next.colon) {
                        this.rule(part);
                    } else if (moreIndent && !next.colon) {
                        this.decl(part);
                    }
                }
            } else if (part.end) {
                this.root.raws.after = part.before;
            } else {
                this.rule(part);
            }

            this.pos += 1;
        }
    };

    Parser.prototype.comment = function comment(part) {
        var token = part.tokens[0];
        var node = new _comment2.default();
        this.init(node, part);
        node.source.end = { line: token[4], column: token[5] };
        this.commentText(node, token);
    };

    Parser.prototype.atrule = function atrule(part) {
        var atword = part.tokens[0];
        var params = part.tokens.slice(1);

        var node = new _atRule2.default();
        node.name = atword[1].slice(1);
        this.init(node, part);

        if (node.name === '') this.unnamedAtrule(atword);

        while (!part.end && part.lastComma) {
            this.pos += 1;
            part = this.parts[this.pos];
            params.push(['space', part.before + part.indent]);
            params = params.concat(part.tokens);
        }

        node.raws.afterName = this.firstSpaces(params);
        this.keepTrailingSpace(node, params);
        this.raw(node, 'params', params, atword);
    };

    Parser.prototype.decl = function decl(part) {
        var node = new _declaration2.default();
        this.init(node, part);

        var between = '';
        var colon = 0;
        var value = [];
        var prop = '';
        for (var i = 0; i < part.tokens.length; i++) {
            var token = part.tokens[i];
            if (token[0] === ':') {
                between += token[1];
                colon = token;
                value = part.tokens.slice(i + 1);
                break;
            } else if (token[0] === 'comment' || token[0] === 'space') {
                between += token[1];
            } else if (between !== '') {
                this.badProp(token);
            } else {
                prop += token[1];
            }
        }

        if (prop === '') this.unnamedDecl(part.tokens[0]);
        node.prop = prop;

        var next = this.parts[this.pos + 1];

        while (!next.end && !next.atrule && !next.colon && next.indent.length > part.indent.length) {
            value.push(['space', next.before + next.indent]);
            value = value.concat(next.tokens);
            this.pos += 1;
            next = this.parts[this.pos + 1];
        }

        var last = value[value.length - 1];
        if (last && last[0] === 'comment') {
            value.pop();
            var comment = new _comment2.default();
            this.current.push(comment);
            comment.source = {
                input: this.input,
                start: { line: last[2], column: last[3] },
                end: { line: last[4], column: last[5] }
            };
            var prev = value[value.length - 1];
            if (prev && prev[0] === 'space') {
                value.pop();
                comment.raws.before = prev[1];
            }
            this.commentText(comment, last);
        }

        for (var _i = value.length - 1; _i > 0; _i--) {
            var t = value[_i][0];
            if (t === 'word' && value[_i][1] === '!important') {
                node.important = true;
                if (_i > 0 && value[_i - 1][0] === 'space') {
                    node.raws.important = value[_i - 1][1] + '!important';
                    value.splice(_i - 1, 2);
                } else {
                    node.raws.important = '!important';
                    value.splice(_i, 1);
                }
                break;
            } else if (t !== 'space' && t !== 'newline' && t !== 'comment') {
                break;
            }
        }

        node.raws.between = between + this.firstSpaces(value);
        this.raw(node, 'value', value, colon);
    };

    Parser.prototype.rule = function rule(part) {
        var node = new _rule2.default();
        this.init(node, part);

        var selector = part.tokens;
        var next = this.parts[this.pos + 1];

        while (!next.end && next.indent.length === part.indent.length) {
            selector.push(['space', next.before + next.indent]);
            selector = selector.concat(next.tokens);
            this.pos += 1;
            next = this.parts[this.pos + 1];
        }

        this.keepTrailingSpace(node, selector);
        this.raw(node, 'selector', selector);
    };

    /* Helpers */

    Parser.prototype.indent = function indent(part) {
        var indent = part.indent.length;
        var isPrev = typeof this.prevIndent !== 'undefined';

        if (!isPrev && indent) this.indentedFirstLine(part);

        if (!this.step && indent) {
            this.step = indent;
            this.root.raws.indent = part.indent;
        }

        if (isPrev && this.prevIndent !== indent) {
            var diff = indent - this.prevIndent;
            if (diff > 0) {
                if (diff !== this.step) {
                    this.wrongIndent(this.prevIndent + this.step, indent, part);
                } else {
                    this.current = this.current.last;
                }
            } else if (diff % this.step !== 0) {
                var m = indent + diff % this.step;
                this.wrongIndent(m + ' or ' + (m + this.step), indent, part);
            } else {
                for (var i = 0; i < -diff / this.step; i++) {
                    this.current = this.current.parent;
                }
            }
        }

        this.prevIndent = indent;
    };

    Parser.prototype.init = function init(node, part) {
        this.indent(part);

        if (!this.current.nodes) this.current.nodes = [];
        this.current.push(node);

        node.raws.before = part.before + part.indent;
        node.source = {
            start: { line: part.tokens[0][2], column: part.tokens[0][3] },
            input: this.input
        };
    };

    Parser.prototype.keepTrailingSpace = function keepTrailingSpace(node, tokens) {
        var lastSpace = tokens[tokens.length - 1];
        if (lastSpace && lastSpace[0] === 'space') {
            tokens.pop();
            node.raws.sssBetween = lastSpace[1];
        }
    };

    Parser.prototype.firstSpaces = function firstSpaces(tokens) {
        var result = '';
        for (var i = 0; i < tokens.length; i++) {
            if (tokens[i][0] === 'space' || tokens[i][0] === 'newline') {
                result += tokens.shift()[1];
                i -= 1;
            } else {
                break;
            }
        }
        return result;
    };

    Parser.prototype.raw = function raw(node, prop, tokens, altLast) {
        var token = void 0,
            type = void 0;
        var length = tokens.length;
        var value = '';
        var clean = true;
        for (var i = 0; i < length; i += 1) {
            token = tokens[i];
            type = token[0];
            if (type === 'comment' || type === 'space' && i === length - 1) {
                clean = false;
            } else {
                value += token[1];
            }
        }
        if (!clean) {
            var sss = tokens.reduce(function (all, i) {
                return all + i[1];
            }, '');
            var raw = tokens.reduce(function (all, i) {
                if (i[0] === 'comment' && i[6] === 'inline') {
                    return all + '/* ' + i[1].slice(2).trim() + ' */';
                } else {
                    return all + i[1];
                }
            }, '');
            node.raws[prop] = { value: value, raw: raw };
            if (sss !== raw) node.raws[prop].sss = sss;
        }
        node[prop] = value;

        var last = tokens[tokens.length - 1] || altLast;
        node.source.end = {
            line: last[4] || last[2],
            column: last[5] || last[3]
        };
    };

    Parser.prototype.nextNonComment = function nextNonComment(pos) {
        var next = pos;
        var part = void 0;
        while (next < this.parts.length) {
            next += 1;
            part = this.parts[next];
            if (part.end || !part.comment) break;
        }
        return part;
    };

    Parser.prototype.commentText = function commentText(node, token) {
        var text = token[1];
        if (token[6] === 'inline') {
            node.raws.inline = true;
            text = text.slice(2);
        } else {
            text = text.slice(2, -2);
        }

        var match = text.match(/^(\s*)([^]*[^\s])(\s*)\n?$/);
        if (match) {
            node.text = match[2];
            node.raws.left = match[1];
            node.raws.inlineRight = match[3];
        } else {
            node.text = '';
            node.raws.left = '';
            node.raws.inlineRight = '';
        }
    };

    // Errors

    Parser.prototype.error = function error(msg, line, column) {
        throw this.input.error(msg, line, column);
    };

    Parser.prototype.unnamedAtrule = function unnamedAtrule(token) {
        this.error('At-rule without name', token[2], token[3]);
    };

    Parser.prototype.unnamedDecl = function unnamedDecl(token) {
        this.error('Declaration without name', token[2], token[3]);
    };

    Parser.prototype.indentedFirstLine = function indentedFirstLine(part) {
        this.error('First line should not have indent', part.number, 1);
    };

    Parser.prototype.wrongIndent = function wrongIndent(expected, real, part) {
        var msg = 'Expected ' + expected + ' indent, but get ' + real;
        this.error(msg, part.number, 1);
    };

    Parser.prototype.badProp = function badProp(token) {
        this.error('Unexpected separator in property', token[2], token[3]);
    };

    return Parser;
}();

exports.default = Parser;
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhcnNlci5lczYiXSwibmFtZXMiOlsiUGFyc2VyIiwiaW5wdXQiLCJwb3MiLCJyb290IiwiY3VycmVudCIsInNwYWNlcyIsInByZXZJbmRlbnQiLCJ1bmRlZmluZWQiLCJzdGVwIiwic291cmNlIiwic3RhcnQiLCJsaW5lIiwiY29sdW1uIiwibG9vcCIsInBhcnQiLCJwYXJ0cyIsImxlbmd0aCIsImNvbW1lbnQiLCJhdHJ1bGUiLCJjb2xvbiIsIm5leHQiLCJuZXh0Tm9uQ29tbWVudCIsImVuZCIsImRlY2wiLCJtb3JlSW5kZW50IiwiaW5kZW50IiwicnVsZSIsInJhd3MiLCJhZnRlciIsImJlZm9yZSIsInRva2VuIiwidG9rZW5zIiwibm9kZSIsImluaXQiLCJjb21tZW50VGV4dCIsImF0d29yZCIsInBhcmFtcyIsInNsaWNlIiwibmFtZSIsInVubmFtZWRBdHJ1bGUiLCJsYXN0Q29tbWEiLCJwdXNoIiwiY29uY2F0IiwiYWZ0ZXJOYW1lIiwiZmlyc3RTcGFjZXMiLCJrZWVwVHJhaWxpbmdTcGFjZSIsInJhdyIsImJldHdlZW4iLCJ2YWx1ZSIsInByb3AiLCJpIiwiYmFkUHJvcCIsInVubmFtZWREZWNsIiwibGFzdCIsInBvcCIsInByZXYiLCJ0IiwiaW1wb3J0YW50Iiwic3BsaWNlIiwic2VsZWN0b3IiLCJpc1ByZXYiLCJpbmRlbnRlZEZpcnN0TGluZSIsImRpZmYiLCJ3cm9uZ0luZGVudCIsIm0iLCJwYXJlbnQiLCJub2RlcyIsImxhc3RTcGFjZSIsInNzc0JldHdlZW4iLCJyZXN1bHQiLCJzaGlmdCIsImFsdExhc3QiLCJ0eXBlIiwiY2xlYW4iLCJzc3MiLCJyZWR1Y2UiLCJhbGwiLCJ0cmltIiwidGV4dCIsImlubGluZSIsIm1hdGNoIiwibGVmdCIsImlubGluZVJpZ2h0IiwiZXJyb3IiLCJtc2ciLCJudW1iZXIiLCJleHBlY3RlZCIsInJlYWwiXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7OztJQUVxQkEsTTtBQUVqQixvQkFBWUMsS0FBWixFQUFtQjtBQUFBOztBQUNmLGFBQUtBLEtBQUwsR0FBYUEsS0FBYjs7QUFFQSxhQUFLQyxHQUFMLEdBQWUsQ0FBZjtBQUNBLGFBQUtDLElBQUwsR0FBZSxvQkFBZjtBQUNBLGFBQUtDLE9BQUwsR0FBZSxLQUFLRCxJQUFwQjtBQUNBLGFBQUtFLE1BQUwsR0FBZSxFQUFmOztBQUVBLGFBQUtDLFVBQUwsR0FBa0JDLFNBQWxCO0FBQ0EsYUFBS0MsSUFBTCxHQUFrQkQsU0FBbEI7O0FBRUEsYUFBS0osSUFBTCxDQUFVTSxNQUFWLEdBQW1CLEVBQUVSLFlBQUYsRUFBU1MsT0FBTyxFQUFFQyxNQUFNLENBQVIsRUFBV0MsUUFBUSxDQUFuQixFQUFoQixFQUFuQjtBQUNIOztxQkFFREMsSSxtQkFBTztBQUNILFlBQUlDLGFBQUo7QUFDQSxlQUFRLEtBQUtaLEdBQUwsR0FBVyxLQUFLYSxLQUFMLENBQVdDLE1BQTlCLEVBQXVDO0FBQ25DRixtQkFBTyxLQUFLQyxLQUFMLENBQVcsS0FBS2IsR0FBaEIsQ0FBUDs7QUFFQSxnQkFBS1ksS0FBS0csT0FBVixFQUFvQjtBQUNoQixxQkFBS0EsT0FBTCxDQUFhSCxJQUFiO0FBQ0gsYUFGRCxNQUVPLElBQUtBLEtBQUtJLE1BQVYsRUFBbUI7QUFDdEIscUJBQUtBLE1BQUwsQ0FBWUosSUFBWjtBQUNILGFBRk0sTUFFQSxJQUFLQSxLQUFLSyxLQUFWLEVBQWtCO0FBQ3JCLG9CQUFJQyxPQUFPLEtBQUtDLGNBQUwsQ0FBb0IsS0FBS25CLEdBQXpCLENBQVg7O0FBRUEsb0JBQUtrQixLQUFLRSxHQUFMLElBQVlGLEtBQUtGLE1BQXRCLEVBQStCO0FBQzNCLHlCQUFLSyxJQUFMLENBQVVULElBQVY7QUFDSCxpQkFGRCxNQUVPO0FBQ0gsd0JBQUlVLGFBQWFKLEtBQUtLLE1BQUwsQ0FBWVQsTUFBWixHQUFxQkYsS0FBS1csTUFBTCxDQUFZVCxNQUFsRDtBQUNBLHdCQUFLLENBQUNRLFVBQU4sRUFBbUI7QUFDZiw2QkFBS0QsSUFBTCxDQUFVVCxJQUFWO0FBQ0gscUJBRkQsTUFFTyxJQUFLVSxjQUFjSixLQUFLRCxLQUF4QixFQUFnQztBQUNuQyw2QkFBS08sSUFBTCxDQUFVWixJQUFWO0FBQ0gscUJBRk0sTUFFQSxJQUFLVSxjQUFjLENBQUNKLEtBQUtELEtBQXpCLEVBQWlDO0FBQ3BDLDZCQUFLSSxJQUFMLENBQVVULElBQVY7QUFDSDtBQUNKO0FBQ0osYUFmTSxNQWVBLElBQUtBLEtBQUtRLEdBQVYsRUFBZ0I7QUFDbkIscUJBQUtuQixJQUFMLENBQVV3QixJQUFWLENBQWVDLEtBQWYsR0FBdUJkLEtBQUtlLE1BQTVCO0FBQ0gsYUFGTSxNQUVBO0FBQ0gscUJBQUtILElBQUwsQ0FBVVosSUFBVjtBQUNIOztBQUVELGlCQUFLWixHQUFMLElBQVksQ0FBWjtBQUNIO0FBQ0osSzs7cUJBRURlLE8sb0JBQVFILEksRUFBTTtBQUNWLFlBQUlnQixRQUFRaEIsS0FBS2lCLE1BQUwsQ0FBWSxDQUFaLENBQVo7QUFDQSxZQUFJQyxPQUFRLHVCQUFaO0FBQ0EsYUFBS0MsSUFBTCxDQUFVRCxJQUFWLEVBQWdCbEIsSUFBaEI7QUFDQWtCLGFBQUt2QixNQUFMLENBQVlhLEdBQVosR0FBa0IsRUFBRVgsTUFBTW1CLE1BQU0sQ0FBTixDQUFSLEVBQWtCbEIsUUFBUWtCLE1BQU0sQ0FBTixDQUExQixFQUFsQjtBQUNBLGFBQUtJLFdBQUwsQ0FBaUJGLElBQWpCLEVBQXVCRixLQUF2QjtBQUNILEs7O3FCQUVEWixNLG1CQUFPSixJLEVBQU07QUFDVCxZQUFJcUIsU0FBU3JCLEtBQUtpQixNQUFMLENBQVksQ0FBWixDQUFiO0FBQ0EsWUFBSUssU0FBU3RCLEtBQUtpQixNQUFMLENBQVlNLEtBQVosQ0FBa0IsQ0FBbEIsQ0FBYjs7QUFFQSxZQUFJTCxPQUFRLHNCQUFaO0FBQ0FBLGFBQUtNLElBQUwsR0FBWUgsT0FBTyxDQUFQLEVBQVVFLEtBQVYsQ0FBZ0IsQ0FBaEIsQ0FBWjtBQUNBLGFBQUtKLElBQUwsQ0FBVUQsSUFBVixFQUFnQmxCLElBQWhCOztBQUVBLFlBQUtrQixLQUFLTSxJQUFMLEtBQWMsRUFBbkIsRUFBd0IsS0FBS0MsYUFBTCxDQUFtQkosTUFBbkI7O0FBRXhCLGVBQVEsQ0FBQ3JCLEtBQUtRLEdBQU4sSUFBYVIsS0FBSzBCLFNBQTFCLEVBQXNDO0FBQ2xDLGlCQUFLdEMsR0FBTCxJQUFZLENBQVo7QUFDQVksbUJBQU8sS0FBS0MsS0FBTCxDQUFXLEtBQUtiLEdBQWhCLENBQVA7QUFDQWtDLG1CQUFPSyxJQUFQLENBQVksQ0FBQyxPQUFELEVBQVUzQixLQUFLZSxNQUFMLEdBQWNmLEtBQUtXLE1BQTdCLENBQVo7QUFDQVcscUJBQVNBLE9BQU9NLE1BQVAsQ0FBYzVCLEtBQUtpQixNQUFuQixDQUFUO0FBQ0g7O0FBRURDLGFBQUtMLElBQUwsQ0FBVWdCLFNBQVYsR0FBc0IsS0FBS0MsV0FBTCxDQUFpQlIsTUFBakIsQ0FBdEI7QUFDQSxhQUFLUyxpQkFBTCxDQUF1QmIsSUFBdkIsRUFBNkJJLE1BQTdCO0FBQ0EsYUFBS1UsR0FBTCxDQUFTZCxJQUFULEVBQWUsUUFBZixFQUF5QkksTUFBekIsRUFBaUNELE1BQWpDO0FBQ0gsSzs7cUJBRURaLEksaUJBQUtULEksRUFBTTtBQUNQLFlBQUlrQixPQUFPLDJCQUFYO0FBQ0EsYUFBS0MsSUFBTCxDQUFVRCxJQUFWLEVBQWdCbEIsSUFBaEI7O0FBRUEsWUFBSWlDLFVBQVUsRUFBZDtBQUNBLFlBQUk1QixRQUFVLENBQWQ7QUFDQSxZQUFJNkIsUUFBVSxFQUFkO0FBQ0EsWUFBSUMsT0FBVSxFQUFkO0FBQ0EsYUFBTSxJQUFJQyxJQUFJLENBQWQsRUFBaUJBLElBQUlwQyxLQUFLaUIsTUFBTCxDQUFZZixNQUFqQyxFQUF5Q2tDLEdBQXpDLEVBQStDO0FBQzNDLGdCQUFJcEIsUUFBUWhCLEtBQUtpQixNQUFMLENBQVltQixDQUFaLENBQVo7QUFDQSxnQkFBS3BCLE1BQU0sQ0FBTixNQUFhLEdBQWxCLEVBQXdCO0FBQ3BCaUIsMkJBQVdqQixNQUFNLENBQU4sQ0FBWDtBQUNBWCx3QkFBV1csS0FBWDtBQUNBa0Isd0JBQVdsQyxLQUFLaUIsTUFBTCxDQUFZTSxLQUFaLENBQWtCYSxJQUFJLENBQXRCLENBQVg7QUFDQTtBQUNILGFBTEQsTUFLTyxJQUFLcEIsTUFBTSxDQUFOLE1BQWEsU0FBYixJQUEwQkEsTUFBTSxDQUFOLE1BQWEsT0FBNUMsRUFBc0Q7QUFDekRpQiwyQkFBV2pCLE1BQU0sQ0FBTixDQUFYO0FBQ0gsYUFGTSxNQUVBLElBQUtpQixZQUFZLEVBQWpCLEVBQXNCO0FBQ3pCLHFCQUFLSSxPQUFMLENBQWFyQixLQUFiO0FBQ0gsYUFGTSxNQUVBO0FBQ0htQix3QkFBUW5CLE1BQU0sQ0FBTixDQUFSO0FBQ0g7QUFDSjs7QUFFRCxZQUFLbUIsU0FBUyxFQUFkLEVBQW1CLEtBQUtHLFdBQUwsQ0FBaUJ0QyxLQUFLaUIsTUFBTCxDQUFZLENBQVosQ0FBakI7QUFDbkJDLGFBQUtpQixJQUFMLEdBQVlBLElBQVo7O0FBRUEsWUFBSTdCLE9BQU8sS0FBS0wsS0FBTCxDQUFXLEtBQUtiLEdBQUwsR0FBVyxDQUF0QixDQUFYOztBQUVBLGVBQVEsQ0FBQ2tCLEtBQUtFLEdBQU4sSUFBYSxDQUFDRixLQUFLRixNQUFuQixJQUE2QixDQUFDRSxLQUFLRCxLQUFuQyxJQUNBQyxLQUFLSyxNQUFMLENBQVlULE1BQVosR0FBcUJGLEtBQUtXLE1BQUwsQ0FBWVQsTUFEekMsRUFDa0Q7QUFDOUNnQyxrQkFBTVAsSUFBTixDQUFXLENBQUMsT0FBRCxFQUFVckIsS0FBS1MsTUFBTCxHQUFjVCxLQUFLSyxNQUE3QixDQUFYO0FBQ0F1QixvQkFBUUEsTUFBTU4sTUFBTixDQUFhdEIsS0FBS1csTUFBbEIsQ0FBUjtBQUNBLGlCQUFLN0IsR0FBTCxJQUFZLENBQVo7QUFDQWtCLG1CQUFPLEtBQUtMLEtBQUwsQ0FBVyxLQUFLYixHQUFMLEdBQVcsQ0FBdEIsQ0FBUDtBQUNIOztBQUVELFlBQUltRCxPQUFPTCxNQUFNQSxNQUFNaEMsTUFBTixHQUFlLENBQXJCLENBQVg7QUFDQSxZQUFLcUMsUUFBUUEsS0FBSyxDQUFMLE1BQVksU0FBekIsRUFBcUM7QUFDakNMLGtCQUFNTSxHQUFOO0FBQ0EsZ0JBQUlyQyxVQUFVLHVCQUFkO0FBQ0EsaUJBQUtiLE9BQUwsQ0FBYXFDLElBQWIsQ0FBa0J4QixPQUFsQjtBQUNBQSxvQkFBUVIsTUFBUixHQUFpQjtBQUNiUix1QkFBTyxLQUFLQSxLQURDO0FBRWJTLHVCQUFPLEVBQUVDLE1BQU0wQyxLQUFLLENBQUwsQ0FBUixFQUFpQnpDLFFBQVF5QyxLQUFLLENBQUwsQ0FBekIsRUFGTTtBQUdiL0IscUJBQU8sRUFBRVgsTUFBTTBDLEtBQUssQ0FBTCxDQUFSLEVBQWlCekMsUUFBUXlDLEtBQUssQ0FBTCxDQUF6QjtBQUhNLGFBQWpCO0FBS0EsZ0JBQUlFLE9BQU9QLE1BQU1BLE1BQU1oQyxNQUFOLEdBQWUsQ0FBckIsQ0FBWDtBQUNBLGdCQUFLdUMsUUFBUUEsS0FBSyxDQUFMLE1BQVksT0FBekIsRUFBbUM7QUFDL0JQLHNCQUFNTSxHQUFOO0FBQ0FyQyx3QkFBUVUsSUFBUixDQUFhRSxNQUFiLEdBQXNCMEIsS0FBSyxDQUFMLENBQXRCO0FBQ0g7QUFDRCxpQkFBS3JCLFdBQUwsQ0FBaUJqQixPQUFqQixFQUEwQm9DLElBQTFCO0FBQ0g7O0FBRUQsYUFBTSxJQUFJSCxLQUFJRixNQUFNaEMsTUFBTixHQUFlLENBQTdCLEVBQWdDa0MsS0FBSSxDQUFwQyxFQUF1Q0EsSUFBdkMsRUFBNkM7QUFDekMsZ0JBQUlNLElBQUlSLE1BQU1FLEVBQU4sRUFBUyxDQUFULENBQVI7QUFDQSxnQkFBS00sTUFBTSxNQUFOLElBQWdCUixNQUFNRSxFQUFOLEVBQVMsQ0FBVCxNQUFnQixZQUFyQyxFQUFvRDtBQUNoRGxCLHFCQUFLeUIsU0FBTCxHQUFpQixJQUFqQjtBQUNBLG9CQUFLUCxLQUFJLENBQUosSUFBU0YsTUFBTUUsS0FBSSxDQUFWLEVBQWEsQ0FBYixNQUFvQixPQUFsQyxFQUE0QztBQUN4Q2xCLHlCQUFLTCxJQUFMLENBQVU4QixTQUFWLEdBQXNCVCxNQUFNRSxLQUFJLENBQVYsRUFBYSxDQUFiLElBQWtCLFlBQXhDO0FBQ0FGLDBCQUFNVSxNQUFOLENBQWFSLEtBQUksQ0FBakIsRUFBb0IsQ0FBcEI7QUFDSCxpQkFIRCxNQUdPO0FBQ0hsQix5QkFBS0wsSUFBTCxDQUFVOEIsU0FBVixHQUFzQixZQUF0QjtBQUNBVCwwQkFBTVUsTUFBTixDQUFhUixFQUFiLEVBQWdCLENBQWhCO0FBQ0g7QUFDRDtBQUNILGFBVkQsTUFVTyxJQUFLTSxNQUFNLE9BQU4sSUFBaUJBLE1BQU0sU0FBdkIsSUFBb0NBLE1BQU0sU0FBL0MsRUFBMkQ7QUFDOUQ7QUFDSDtBQUNKOztBQUVEeEIsYUFBS0wsSUFBTCxDQUFVb0IsT0FBVixHQUFvQkEsVUFBVSxLQUFLSCxXQUFMLENBQWlCSSxLQUFqQixDQUE5QjtBQUNBLGFBQUtGLEdBQUwsQ0FBU2QsSUFBVCxFQUFlLE9BQWYsRUFBd0JnQixLQUF4QixFQUErQjdCLEtBQS9CO0FBQ0gsSzs7cUJBRURPLEksaUJBQUtaLEksRUFBTTtBQUNQLFlBQUlrQixPQUFPLG9CQUFYO0FBQ0EsYUFBS0MsSUFBTCxDQUFVRCxJQUFWLEVBQWdCbEIsSUFBaEI7O0FBRUEsWUFBSTZDLFdBQVc3QyxLQUFLaUIsTUFBcEI7QUFDQSxZQUFJWCxPQUFXLEtBQUtMLEtBQUwsQ0FBVyxLQUFLYixHQUFMLEdBQVcsQ0FBdEIsQ0FBZjs7QUFFQSxlQUFRLENBQUNrQixLQUFLRSxHQUFOLElBQWFGLEtBQUtLLE1BQUwsQ0FBWVQsTUFBWixLQUF1QkYsS0FBS1csTUFBTCxDQUFZVCxNQUF4RCxFQUFpRTtBQUM3RDJDLHFCQUFTbEIsSUFBVCxDQUFjLENBQUMsT0FBRCxFQUFVckIsS0FBS1MsTUFBTCxHQUFjVCxLQUFLSyxNQUE3QixDQUFkO0FBQ0FrQyx1QkFBV0EsU0FBU2pCLE1BQVQsQ0FBZ0J0QixLQUFLVyxNQUFyQixDQUFYO0FBQ0EsaUJBQUs3QixHQUFMLElBQVksQ0FBWjtBQUNBa0IsbUJBQU8sS0FBS0wsS0FBTCxDQUFXLEtBQUtiLEdBQUwsR0FBVyxDQUF0QixDQUFQO0FBQ0g7O0FBRUQsYUFBSzJDLGlCQUFMLENBQXVCYixJQUF2QixFQUE2QjJCLFFBQTdCO0FBQ0EsYUFBS2IsR0FBTCxDQUFTZCxJQUFULEVBQWUsVUFBZixFQUEyQjJCLFFBQTNCO0FBQ0gsSzs7QUFFRDs7cUJBRUFsQyxNLG1CQUFPWCxJLEVBQU07QUFDVCxZQUFJVyxTQUFTWCxLQUFLVyxNQUFMLENBQVlULE1BQXpCO0FBQ0EsWUFBSTRDLFNBQVMsT0FBTyxLQUFLdEQsVUFBWixLQUEyQixXQUF4Qzs7QUFFQSxZQUFLLENBQUNzRCxNQUFELElBQVduQyxNQUFoQixFQUF5QixLQUFLb0MsaUJBQUwsQ0FBdUIvQyxJQUF2Qjs7QUFFekIsWUFBSyxDQUFDLEtBQUtOLElBQU4sSUFBY2lCLE1BQW5CLEVBQTRCO0FBQ3hCLGlCQUFLakIsSUFBTCxHQUFZaUIsTUFBWjtBQUNBLGlCQUFLdEIsSUFBTCxDQUFVd0IsSUFBVixDQUFlRixNQUFmLEdBQXdCWCxLQUFLVyxNQUE3QjtBQUNIOztBQUVELFlBQUttQyxVQUFVLEtBQUt0RCxVQUFMLEtBQW9CbUIsTUFBbkMsRUFBNEM7QUFDeEMsZ0JBQUlxQyxPQUFPckMsU0FBUyxLQUFLbkIsVUFBekI7QUFDQSxnQkFBS3dELE9BQU8sQ0FBWixFQUFnQjtBQUNaLG9CQUFLQSxTQUFTLEtBQUt0RCxJQUFuQixFQUEwQjtBQUN0Qix5QkFBS3VELFdBQUwsQ0FBaUIsS0FBS3pELFVBQUwsR0FBa0IsS0FBS0UsSUFBeEMsRUFBOENpQixNQUE5QyxFQUFzRFgsSUFBdEQ7QUFDSCxpQkFGRCxNQUVPO0FBQ0gseUJBQUtWLE9BQUwsR0FBZSxLQUFLQSxPQUFMLENBQWFpRCxJQUE1QjtBQUNIO0FBQ0osYUFORCxNQU1PLElBQUtTLE9BQU8sS0FBS3RELElBQVosS0FBcUIsQ0FBMUIsRUFBOEI7QUFDakMsb0JBQUl3RCxJQUFJdkMsU0FBU3FDLE9BQU8sS0FBS3RELElBQTdCO0FBQ0EscUJBQUt1RCxXQUFMLENBQXFCQyxDQUFyQixhQUErQkEsSUFBSSxLQUFLeEQsSUFBeEMsR0FBaURpQixNQUFqRCxFQUF5RFgsSUFBekQ7QUFDSCxhQUhNLE1BR0E7QUFDSCxxQkFBTSxJQUFJb0MsSUFBSSxDQUFkLEVBQWlCQSxJQUFJLENBQUNZLElBQUQsR0FBUSxLQUFLdEQsSUFBbEMsRUFBd0MwQyxHQUF4QyxFQUE4QztBQUMxQyx5QkFBSzlDLE9BQUwsR0FBZSxLQUFLQSxPQUFMLENBQWE2RCxNQUE1QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxhQUFLM0QsVUFBTCxHQUFrQm1CLE1BQWxCO0FBQ0gsSzs7cUJBRURRLEksaUJBQUtELEksRUFBTWxCLEksRUFBTTtBQUNiLGFBQUtXLE1BQUwsQ0FBWVgsSUFBWjs7QUFFQSxZQUFLLENBQUMsS0FBS1YsT0FBTCxDQUFhOEQsS0FBbkIsRUFBMkIsS0FBSzlELE9BQUwsQ0FBYThELEtBQWIsR0FBcUIsRUFBckI7QUFDM0IsYUFBSzlELE9BQUwsQ0FBYXFDLElBQWIsQ0FBa0JULElBQWxCOztBQUVBQSxhQUFLTCxJQUFMLENBQVVFLE1BQVYsR0FBbUJmLEtBQUtlLE1BQUwsR0FBY2YsS0FBS1csTUFBdEM7QUFDQU8sYUFBS3ZCLE1BQUwsR0FBYztBQUNWQyxtQkFBTyxFQUFFQyxNQUFNRyxLQUFLaUIsTUFBTCxDQUFZLENBQVosRUFBZSxDQUFmLENBQVIsRUFBMkJuQixRQUFRRSxLQUFLaUIsTUFBTCxDQUFZLENBQVosRUFBZSxDQUFmLENBQW5DLEVBREc7QUFFVjlCLG1CQUFPLEtBQUtBO0FBRkYsU0FBZDtBQUlILEs7O3FCQUVENEMsaUIsOEJBQWtCYixJLEVBQU1ELE0sRUFBUTtBQUM1QixZQUFJb0MsWUFBWXBDLE9BQU9BLE9BQU9mLE1BQVAsR0FBZ0IsQ0FBdkIsQ0FBaEI7QUFDQSxZQUFLbUQsYUFBYUEsVUFBVSxDQUFWLE1BQWlCLE9BQW5DLEVBQTZDO0FBQ3pDcEMsbUJBQU91QixHQUFQO0FBQ0F0QixpQkFBS0wsSUFBTCxDQUFVeUMsVUFBVixHQUF1QkQsVUFBVSxDQUFWLENBQXZCO0FBQ0g7QUFDSixLOztxQkFFRHZCLFcsd0JBQVliLE0sRUFBUTtBQUNoQixZQUFJc0MsU0FBUyxFQUFiO0FBQ0EsYUFBTSxJQUFJbkIsSUFBSSxDQUFkLEVBQWlCQSxJQUFJbkIsT0FBT2YsTUFBNUIsRUFBb0NrQyxHQUFwQyxFQUEwQztBQUN0QyxnQkFBS25CLE9BQU9tQixDQUFQLEVBQVUsQ0FBVixNQUFpQixPQUFqQixJQUE0Qm5CLE9BQU9tQixDQUFQLEVBQVUsQ0FBVixNQUFpQixTQUFsRCxFQUE4RDtBQUMxRG1CLDBCQUFVdEMsT0FBT3VDLEtBQVAsR0FBZSxDQUFmLENBQVY7QUFDQXBCLHFCQUFLLENBQUw7QUFDSCxhQUhELE1BR087QUFDSDtBQUNIO0FBQ0o7QUFDRCxlQUFPbUIsTUFBUDtBQUNILEs7O3FCQUVEdkIsRyxnQkFBSWQsSSxFQUFNaUIsSSxFQUFNbEIsTSxFQUFRd0MsTyxFQUFTO0FBQzdCLFlBQUl6QyxjQUFKO0FBQUEsWUFBVzBDLGFBQVg7QUFDQSxZQUFJeEQsU0FBU2UsT0FBT2YsTUFBcEI7QUFDQSxZQUFJZ0MsUUFBUyxFQUFiO0FBQ0EsWUFBSXlCLFFBQVMsSUFBYjtBQUNBLGFBQU0sSUFBSXZCLElBQUksQ0FBZCxFQUFpQkEsSUFBSWxDLE1BQXJCLEVBQTZCa0MsS0FBSyxDQUFsQyxFQUFzQztBQUNsQ3BCLG9CQUFRQyxPQUFPbUIsQ0FBUCxDQUFSO0FBQ0FzQixtQkFBUTFDLE1BQU0sQ0FBTixDQUFSO0FBQ0EsZ0JBQUswQyxTQUFTLFNBQVQsSUFBc0JBLFNBQVMsT0FBVCxJQUFvQnRCLE1BQU1sQyxTQUFTLENBQTlELEVBQWtFO0FBQzlEeUQsd0JBQVEsS0FBUjtBQUNILGFBRkQsTUFFTztBQUNIekIseUJBQVNsQixNQUFNLENBQU4sQ0FBVDtBQUNIO0FBQ0o7QUFDRCxZQUFLLENBQUMyQyxLQUFOLEVBQWM7QUFDVixnQkFBSUMsTUFBTTNDLE9BQU80QyxNQUFQLENBQWUsVUFBQ0MsR0FBRCxFQUFNMUIsQ0FBTjtBQUFBLHVCQUFZMEIsTUFBTTFCLEVBQUUsQ0FBRixDQUFsQjtBQUFBLGFBQWYsRUFBdUMsRUFBdkMsQ0FBVjtBQUNBLGdCQUFJSixNQUFNZixPQUFPNEMsTUFBUCxDQUFlLFVBQUNDLEdBQUQsRUFBTTFCLENBQU4sRUFBWTtBQUNqQyxvQkFBS0EsRUFBRSxDQUFGLE1BQVMsU0FBVCxJQUFzQkEsRUFBRSxDQUFGLE1BQVMsUUFBcEMsRUFBK0M7QUFDM0MsMkJBQU8wQixNQUFNLEtBQU4sR0FBYzFCLEVBQUUsQ0FBRixFQUFLYixLQUFMLENBQVcsQ0FBWCxFQUFjd0MsSUFBZCxFQUFkLEdBQXFDLEtBQTVDO0FBQ0gsaUJBRkQsTUFFTztBQUNILDJCQUFPRCxNQUFNMUIsRUFBRSxDQUFGLENBQWI7QUFDSDtBQUNKLGFBTlMsRUFNUCxFQU5PLENBQVY7QUFPQWxCLGlCQUFLTCxJQUFMLENBQVVzQixJQUFWLElBQWtCLEVBQUVELFlBQUYsRUFBU0YsUUFBVCxFQUFsQjtBQUNBLGdCQUFLNEIsUUFBUTVCLEdBQWIsRUFBbUJkLEtBQUtMLElBQUwsQ0FBVXNCLElBQVYsRUFBZ0J5QixHQUFoQixHQUFzQkEsR0FBdEI7QUFDdEI7QUFDRDFDLGFBQUtpQixJQUFMLElBQWFELEtBQWI7O0FBRUEsWUFBSUssT0FBT3RCLE9BQU9BLE9BQU9mLE1BQVAsR0FBZ0IsQ0FBdkIsS0FBNkJ1RCxPQUF4QztBQUNBdkMsYUFBS3ZCLE1BQUwsQ0FBWWEsR0FBWixHQUFrQjtBQUNkWCxrQkFBUTBDLEtBQUssQ0FBTCxLQUFXQSxLQUFLLENBQUwsQ0FETDtBQUVkekMsb0JBQVF5QyxLQUFLLENBQUwsS0FBV0EsS0FBSyxDQUFMO0FBRkwsU0FBbEI7QUFJSCxLOztxQkFFRGhDLGMsMkJBQWVuQixHLEVBQUs7QUFDaEIsWUFBSWtCLE9BQU9sQixHQUFYO0FBQ0EsWUFBSVksYUFBSjtBQUNBLGVBQVFNLE9BQU8sS0FBS0wsS0FBTCxDQUFXQyxNQUExQixFQUFtQztBQUMvQkksb0JBQVEsQ0FBUjtBQUNBTixtQkFBTyxLQUFLQyxLQUFMLENBQVdLLElBQVgsQ0FBUDtBQUNBLGdCQUFLTixLQUFLUSxHQUFMLElBQVksQ0FBQ1IsS0FBS0csT0FBdkIsRUFBaUM7QUFDcEM7QUFDRCxlQUFPSCxJQUFQO0FBQ0gsSzs7cUJBRURvQixXLHdCQUFZRixJLEVBQU1GLEssRUFBTztBQUNyQixZQUFJZ0QsT0FBT2hELE1BQU0sQ0FBTixDQUFYO0FBQ0EsWUFBS0EsTUFBTSxDQUFOLE1BQWEsUUFBbEIsRUFBNkI7QUFDekJFLGlCQUFLTCxJQUFMLENBQVVvRCxNQUFWLEdBQW1CLElBQW5CO0FBQ0FELG1CQUFPQSxLQUFLekMsS0FBTCxDQUFXLENBQVgsQ0FBUDtBQUNILFNBSEQsTUFHTztBQUNIeUMsbUJBQU9BLEtBQUt6QyxLQUFMLENBQVcsQ0FBWCxFQUFjLENBQUMsQ0FBZixDQUFQO0FBQ0g7O0FBRUQsWUFBSTJDLFFBQVFGLEtBQUtFLEtBQUwsQ0FBVyw0QkFBWCxDQUFaO0FBQ0EsWUFBS0EsS0FBTCxFQUFhO0FBQ1RoRCxpQkFBSzhDLElBQUwsR0FBWUUsTUFBTSxDQUFOLENBQVo7QUFDQWhELGlCQUFLTCxJQUFMLENBQVVzRCxJQUFWLEdBQWlCRCxNQUFNLENBQU4sQ0FBakI7QUFDQWhELGlCQUFLTCxJQUFMLENBQVV1RCxXQUFWLEdBQXdCRixNQUFNLENBQU4sQ0FBeEI7QUFDSCxTQUpELE1BSU87QUFDSGhELGlCQUFLOEMsSUFBTCxHQUFZLEVBQVo7QUFDQTlDLGlCQUFLTCxJQUFMLENBQVVzRCxJQUFWLEdBQWlCLEVBQWpCO0FBQ0FqRCxpQkFBS0wsSUFBTCxDQUFVdUQsV0FBVixHQUF3QixFQUF4QjtBQUNIO0FBQ0osSzs7QUFFRDs7cUJBRUFDLEssa0JBQU1DLEcsRUFBS3pFLEksRUFBTUMsTSxFQUFRO0FBQ3JCLGNBQU0sS0FBS1gsS0FBTCxDQUFXa0YsS0FBWCxDQUFpQkMsR0FBakIsRUFBc0J6RSxJQUF0QixFQUE0QkMsTUFBNUIsQ0FBTjtBQUNILEs7O3FCQUVEMkIsYSwwQkFBY1QsSyxFQUFPO0FBQ2pCLGFBQUtxRCxLQUFMLENBQVcsc0JBQVgsRUFBbUNyRCxNQUFNLENBQU4sQ0FBbkMsRUFBNkNBLE1BQU0sQ0FBTixDQUE3QztBQUNILEs7O3FCQUVEc0IsVyx3QkFBWXRCLEssRUFBTztBQUNmLGFBQUtxRCxLQUFMLENBQVcsMEJBQVgsRUFBdUNyRCxNQUFNLENBQU4sQ0FBdkMsRUFBaURBLE1BQU0sQ0FBTixDQUFqRDtBQUNILEs7O3FCQUVEK0IsaUIsOEJBQWtCL0MsSSxFQUFNO0FBQ3BCLGFBQUtxRSxLQUFMLENBQVcsbUNBQVgsRUFBZ0RyRSxLQUFLdUUsTUFBckQsRUFBNkQsQ0FBN0Q7QUFDSCxLOztxQkFFRHRCLFcsd0JBQVl1QixRLEVBQVVDLEksRUFBTXpFLEksRUFBTTtBQUM5QixZQUFJc0Usb0JBQW1CRSxRQUFuQix5QkFBaURDLElBQXJEO0FBQ0EsYUFBS0osS0FBTCxDQUFXQyxHQUFYLEVBQWdCdEUsS0FBS3VFLE1BQXJCLEVBQTZCLENBQTdCO0FBQ0gsSzs7cUJBRURsQyxPLG9CQUFRckIsSyxFQUFPO0FBQ1gsYUFBS3FELEtBQUwsQ0FBVyxrQ0FBWCxFQUErQ3JELE1BQU0sQ0FBTixDQUEvQyxFQUF5REEsTUFBTSxDQUFOLENBQXpEO0FBQ0gsSzs7Ozs7a0JBOVVnQjlCLE0iLCJmaWxlIjoicGFyc2VyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IERlY2xhcmF0aW9uIGZyb20gJ3Bvc3Rjc3MvbGliL2RlY2xhcmF0aW9uJztcbmltcG9ydCBDb21tZW50ICAgICBmcm9tICdwb3N0Y3NzL2xpYi9jb21tZW50JztcbmltcG9ydCBBdFJ1bGUgICAgICBmcm9tICdwb3N0Y3NzL2xpYi9hdC1ydWxlJztcbmltcG9ydCBSdWxlICAgICAgICBmcm9tICdwb3N0Y3NzL2xpYi9ydWxlJztcbmltcG9ydCBSb290ICAgICAgICBmcm9tICdwb3N0Y3NzL2xpYi9yb290JztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFyc2VyIHtcblxuICAgIGNvbnN0cnVjdG9yKGlucHV0KSB7XG4gICAgICAgIHRoaXMuaW5wdXQgPSBpbnB1dDtcblxuICAgICAgICB0aGlzLnBvcyAgICAgPSAwO1xuICAgICAgICB0aGlzLnJvb3QgICAgPSBuZXcgUm9vdCgpO1xuICAgICAgICB0aGlzLmN1cnJlbnQgPSB0aGlzLnJvb3Q7XG4gICAgICAgIHRoaXMuc3BhY2VzICA9ICcnO1xuXG4gICAgICAgIHRoaXMucHJldkluZGVudCA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5zdGVwICAgICAgID0gdW5kZWZpbmVkO1xuXG4gICAgICAgIHRoaXMucm9vdC5zb3VyY2UgPSB7IGlucHV0LCBzdGFydDogeyBsaW5lOiAxLCBjb2x1bW46IDEgfSB9O1xuICAgIH1cblxuICAgIGxvb3AoKSB7XG4gICAgICAgIGxldCBwYXJ0O1xuICAgICAgICB3aGlsZSAoIHRoaXMucG9zIDwgdGhpcy5wYXJ0cy5sZW5ndGggKSB7XG4gICAgICAgICAgICBwYXJ0ID0gdGhpcy5wYXJ0c1t0aGlzLnBvc107XG5cbiAgICAgICAgICAgIGlmICggcGFydC5jb21tZW50ICkge1xuICAgICAgICAgICAgICAgIHRoaXMuY29tbWVudChwYXJ0KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIHBhcnQuYXRydWxlICkge1xuICAgICAgICAgICAgICAgIHRoaXMuYXRydWxlKHBhcnQpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICggcGFydC5jb2xvbiApIHtcbiAgICAgICAgICAgICAgICBsZXQgbmV4dCA9IHRoaXMubmV4dE5vbkNvbW1lbnQodGhpcy5wb3MpO1xuXG4gICAgICAgICAgICAgICAgaWYgKCBuZXh0LmVuZCB8fCBuZXh0LmF0cnVsZSApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWNsKHBhcnQpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBtb3JlSW5kZW50ID0gbmV4dC5pbmRlbnQubGVuZ3RoID4gcGFydC5pbmRlbnQubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICBpZiAoICFtb3JlSW5kZW50ICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWNsKHBhcnQpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCBtb3JlSW5kZW50ICYmIG5leHQuY29sb24gKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJ1bGUocGFydCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIG1vcmVJbmRlbnQgJiYgIW5leHQuY29sb24gKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRlY2wocGFydCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCBwYXJ0LmVuZCApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJvb3QucmF3cy5hZnRlciA9IHBhcnQuYmVmb3JlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJ1bGUocGFydCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMucG9zICs9IDE7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjb21tZW50KHBhcnQpIHtcbiAgICAgICAgbGV0IHRva2VuID0gcGFydC50b2tlbnNbMF07XG4gICAgICAgIGxldCBub2RlICA9IG5ldyBDb21tZW50KCk7XG4gICAgICAgIHRoaXMuaW5pdChub2RlLCBwYXJ0KTtcbiAgICAgICAgbm9kZS5zb3VyY2UuZW5kID0geyBsaW5lOiB0b2tlbls0XSwgY29sdW1uOiB0b2tlbls1XSB9O1xuICAgICAgICB0aGlzLmNvbW1lbnRUZXh0KG5vZGUsIHRva2VuKTtcbiAgICB9XG5cbiAgICBhdHJ1bGUocGFydCkge1xuICAgICAgICBsZXQgYXR3b3JkID0gcGFydC50b2tlbnNbMF07XG4gICAgICAgIGxldCBwYXJhbXMgPSBwYXJ0LnRva2Vucy5zbGljZSgxKTtcblxuICAgICAgICBsZXQgbm9kZSAgPSBuZXcgQXRSdWxlKCk7XG4gICAgICAgIG5vZGUubmFtZSA9IGF0d29yZFsxXS5zbGljZSgxKTtcbiAgICAgICAgdGhpcy5pbml0KG5vZGUsIHBhcnQpO1xuXG4gICAgICAgIGlmICggbm9kZS5uYW1lID09PSAnJyApIHRoaXMudW5uYW1lZEF0cnVsZShhdHdvcmQpO1xuXG4gICAgICAgIHdoaWxlICggIXBhcnQuZW5kICYmIHBhcnQubGFzdENvbW1hICkge1xuICAgICAgICAgICAgdGhpcy5wb3MgKz0gMTtcbiAgICAgICAgICAgIHBhcnQgPSB0aGlzLnBhcnRzW3RoaXMucG9zXTtcbiAgICAgICAgICAgIHBhcmFtcy5wdXNoKFsnc3BhY2UnLCBwYXJ0LmJlZm9yZSArIHBhcnQuaW5kZW50XSk7XG4gICAgICAgICAgICBwYXJhbXMgPSBwYXJhbXMuY29uY2F0KHBhcnQudG9rZW5zKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG5vZGUucmF3cy5hZnRlck5hbWUgPSB0aGlzLmZpcnN0U3BhY2VzKHBhcmFtcyk7XG4gICAgICAgIHRoaXMua2VlcFRyYWlsaW5nU3BhY2Uobm9kZSwgcGFyYW1zKTtcbiAgICAgICAgdGhpcy5yYXcobm9kZSwgJ3BhcmFtcycsIHBhcmFtcywgYXR3b3JkKTtcbiAgICB9XG5cbiAgICBkZWNsKHBhcnQpIHtcbiAgICAgICAgbGV0IG5vZGUgPSBuZXcgRGVjbGFyYXRpb24oKTtcbiAgICAgICAgdGhpcy5pbml0KG5vZGUsIHBhcnQpO1xuXG4gICAgICAgIGxldCBiZXR3ZWVuID0gJyc7XG4gICAgICAgIGxldCBjb2xvbiAgID0gMDtcbiAgICAgICAgbGV0IHZhbHVlICAgPSBbXTtcbiAgICAgICAgbGV0IHByb3AgICAgPSAnJztcbiAgICAgICAgZm9yICggbGV0IGkgPSAwOyBpIDwgcGFydC50b2tlbnMubGVuZ3RoOyBpKysgKSB7XG4gICAgICAgICAgICBsZXQgdG9rZW4gPSBwYXJ0LnRva2Vuc1tpXTtcbiAgICAgICAgICAgIGlmICggdG9rZW5bMF0gPT09ICc6JyApIHtcbiAgICAgICAgICAgICAgICBiZXR3ZWVuICs9IHRva2VuWzFdO1xuICAgICAgICAgICAgICAgIGNvbG9uICAgID0gdG9rZW47XG4gICAgICAgICAgICAgICAgdmFsdWUgICAgPSBwYXJ0LnRva2Vucy5zbGljZShpICsgMSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCB0b2tlblswXSA9PT0gJ2NvbW1lbnQnIHx8IHRva2VuWzBdID09PSAnc3BhY2UnICkge1xuICAgICAgICAgICAgICAgIGJldHdlZW4gKz0gdG9rZW5bMV07XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCBiZXR3ZWVuICE9PSAnJyApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJhZFByb3AodG9rZW4pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcm9wICs9IHRva2VuWzFdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCBwcm9wID09PSAnJyApIHRoaXMudW5uYW1lZERlY2wocGFydC50b2tlbnNbMF0pO1xuICAgICAgICBub2RlLnByb3AgPSBwcm9wO1xuXG4gICAgICAgIGxldCBuZXh0ID0gdGhpcy5wYXJ0c1t0aGlzLnBvcyArIDFdO1xuXG4gICAgICAgIHdoaWxlICggIW5leHQuZW5kICYmICFuZXh0LmF0cnVsZSAmJiAhbmV4dC5jb2xvbiAmJlxuICAgICAgICAgICAgICAgIG5leHQuaW5kZW50Lmxlbmd0aCA+IHBhcnQuaW5kZW50Lmxlbmd0aCApIHtcbiAgICAgICAgICAgIHZhbHVlLnB1c2goWydzcGFjZScsIG5leHQuYmVmb3JlICsgbmV4dC5pbmRlbnRdKTtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuY29uY2F0KG5leHQudG9rZW5zKTtcbiAgICAgICAgICAgIHRoaXMucG9zICs9IDE7XG4gICAgICAgICAgICBuZXh0ID0gdGhpcy5wYXJ0c1t0aGlzLnBvcyArIDFdO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGxhc3QgPSB2YWx1ZVt2YWx1ZS5sZW5ndGggLSAxXTtcbiAgICAgICAgaWYgKCBsYXN0ICYmIGxhc3RbMF0gPT09ICdjb21tZW50JyApIHtcbiAgICAgICAgICAgIHZhbHVlLnBvcCgpO1xuICAgICAgICAgICAgbGV0IGNvbW1lbnQgPSBuZXcgQ29tbWVudCgpO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50LnB1c2goY29tbWVudCk7XG4gICAgICAgICAgICBjb21tZW50LnNvdXJjZSA9IHtcbiAgICAgICAgICAgICAgICBpbnB1dDogdGhpcy5pbnB1dCxcbiAgICAgICAgICAgICAgICBzdGFydDogeyBsaW5lOiBsYXN0WzJdLCBjb2x1bW46IGxhc3RbM10gfSxcbiAgICAgICAgICAgICAgICBlbmQ6ICAgeyBsaW5lOiBsYXN0WzRdLCBjb2x1bW46IGxhc3RbNV0gfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGxldCBwcmV2ID0gdmFsdWVbdmFsdWUubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICBpZiAoIHByZXYgJiYgcHJldlswXSA9PT0gJ3NwYWNlJyApIHtcbiAgICAgICAgICAgICAgICB2YWx1ZS5wb3AoKTtcbiAgICAgICAgICAgICAgICBjb21tZW50LnJhd3MuYmVmb3JlID0gcHJldlsxXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY29tbWVudFRleHQoY29tbWVudCwgbGFzdCk7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKCBsZXQgaSA9IHZhbHVlLmxlbmd0aCAtIDE7IGkgPiAwOyBpLS0gKSB7XG4gICAgICAgICAgICBsZXQgdCA9IHZhbHVlW2ldWzBdO1xuICAgICAgICAgICAgaWYgKCB0ID09PSAnd29yZCcgJiYgdmFsdWVbaV1bMV0gPT09ICchaW1wb3J0YW50JyApIHtcbiAgICAgICAgICAgICAgICBub2RlLmltcG9ydGFudCA9IHRydWU7XG4gICAgICAgICAgICAgICAgaWYgKCBpID4gMCAmJiB2YWx1ZVtpIC0gMV1bMF0gPT09ICdzcGFjZScgKSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUucmF3cy5pbXBvcnRhbnQgPSB2YWx1ZVtpIC0gMV1bMV0gKyAnIWltcG9ydGFudCc7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlLnNwbGljZShpIC0gMSwgMik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5yYXdzLmltcG9ydGFudCA9ICchaW1wb3J0YW50JztcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIHQgIT09ICdzcGFjZScgJiYgdCAhPT0gJ25ld2xpbmUnICYmIHQgIT09ICdjb21tZW50JyApIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIG5vZGUucmF3cy5iZXR3ZWVuID0gYmV0d2VlbiArIHRoaXMuZmlyc3RTcGFjZXModmFsdWUpO1xuICAgICAgICB0aGlzLnJhdyhub2RlLCAndmFsdWUnLCB2YWx1ZSwgY29sb24pO1xuICAgIH1cblxuICAgIHJ1bGUocGFydCkge1xuICAgICAgICBsZXQgbm9kZSA9IG5ldyBSdWxlKCk7XG4gICAgICAgIHRoaXMuaW5pdChub2RlLCBwYXJ0KTtcblxuICAgICAgICBsZXQgc2VsZWN0b3IgPSBwYXJ0LnRva2VucztcbiAgICAgICAgbGV0IG5leHQgICAgID0gdGhpcy5wYXJ0c1t0aGlzLnBvcyArIDFdO1xuXG4gICAgICAgIHdoaWxlICggIW5leHQuZW5kICYmIG5leHQuaW5kZW50Lmxlbmd0aCA9PT0gcGFydC5pbmRlbnQubGVuZ3RoICkge1xuICAgICAgICAgICAgc2VsZWN0b3IucHVzaChbJ3NwYWNlJywgbmV4dC5iZWZvcmUgKyBuZXh0LmluZGVudF0pO1xuICAgICAgICAgICAgc2VsZWN0b3IgPSBzZWxlY3Rvci5jb25jYXQobmV4dC50b2tlbnMpO1xuICAgICAgICAgICAgdGhpcy5wb3MgKz0gMTtcbiAgICAgICAgICAgIG5leHQgPSB0aGlzLnBhcnRzW3RoaXMucG9zICsgMV07XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmtlZXBUcmFpbGluZ1NwYWNlKG5vZGUsIHNlbGVjdG9yKTtcbiAgICAgICAgdGhpcy5yYXcobm9kZSwgJ3NlbGVjdG9yJywgc2VsZWN0b3IpO1xuICAgIH1cblxuICAgIC8qIEhlbHBlcnMgKi9cblxuICAgIGluZGVudChwYXJ0KSB7XG4gICAgICAgIGxldCBpbmRlbnQgPSBwYXJ0LmluZGVudC5sZW5ndGg7XG4gICAgICAgIGxldCBpc1ByZXYgPSB0eXBlb2YgdGhpcy5wcmV2SW5kZW50ICE9PSAndW5kZWZpbmVkJztcblxuICAgICAgICBpZiAoICFpc1ByZXYgJiYgaW5kZW50ICkgdGhpcy5pbmRlbnRlZEZpcnN0TGluZShwYXJ0KTtcblxuICAgICAgICBpZiAoICF0aGlzLnN0ZXAgJiYgaW5kZW50ICkge1xuICAgICAgICAgICAgdGhpcy5zdGVwID0gaW5kZW50O1xuICAgICAgICAgICAgdGhpcy5yb290LnJhd3MuaW5kZW50ID0gcGFydC5pbmRlbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIGlzUHJldiAmJiB0aGlzLnByZXZJbmRlbnQgIT09IGluZGVudCApIHtcbiAgICAgICAgICAgIGxldCBkaWZmID0gaW5kZW50IC0gdGhpcy5wcmV2SW5kZW50O1xuICAgICAgICAgICAgaWYgKCBkaWZmID4gMCApIHtcbiAgICAgICAgICAgICAgICBpZiAoIGRpZmYgIT09IHRoaXMuc3RlcCApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy53cm9uZ0luZGVudCh0aGlzLnByZXZJbmRlbnQgKyB0aGlzLnN0ZXAsIGluZGVudCwgcGFydCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50ID0gdGhpcy5jdXJyZW50Lmxhc3Q7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICggZGlmZiAlIHRoaXMuc3RlcCAhPT0gMCApIHtcbiAgICAgICAgICAgICAgICBsZXQgbSA9IGluZGVudCArIGRpZmYgJSB0aGlzLnN0ZXA7XG4gICAgICAgICAgICAgICAgdGhpcy53cm9uZ0luZGVudChgJHsgbSB9IG9yICR7IG0gKyB0aGlzLnN0ZXAgfWAsIGluZGVudCwgcGFydCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGZvciAoIGxldCBpID0gMDsgaSA8IC1kaWZmIC8gdGhpcy5zdGVwOyBpKysgKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudCA9IHRoaXMuY3VycmVudC5wYXJlbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5wcmV2SW5kZW50ID0gaW5kZW50O1xuICAgIH1cblxuICAgIGluaXQobm9kZSwgcGFydCkge1xuICAgICAgICB0aGlzLmluZGVudChwYXJ0KTtcblxuICAgICAgICBpZiAoICF0aGlzLmN1cnJlbnQubm9kZXMgKSB0aGlzLmN1cnJlbnQubm9kZXMgPSBbXTtcbiAgICAgICAgdGhpcy5jdXJyZW50LnB1c2gobm9kZSk7XG5cbiAgICAgICAgbm9kZS5yYXdzLmJlZm9yZSA9IHBhcnQuYmVmb3JlICsgcGFydC5pbmRlbnQ7XG4gICAgICAgIG5vZGUuc291cmNlID0ge1xuICAgICAgICAgICAgc3RhcnQ6IHsgbGluZTogcGFydC50b2tlbnNbMF1bMl0sIGNvbHVtbjogcGFydC50b2tlbnNbMF1bM10gfSxcbiAgICAgICAgICAgIGlucHV0OiB0aGlzLmlucHV0XG4gICAgICAgIH07XG4gICAgfVxuXG4gICAga2VlcFRyYWlsaW5nU3BhY2Uobm9kZSwgdG9rZW5zKSB7XG4gICAgICAgIGxldCBsYXN0U3BhY2UgPSB0b2tlbnNbdG9rZW5zLmxlbmd0aCAtIDFdO1xuICAgICAgICBpZiAoIGxhc3RTcGFjZSAmJiBsYXN0U3BhY2VbMF0gPT09ICdzcGFjZScgKSB7XG4gICAgICAgICAgICB0b2tlbnMucG9wKCk7XG4gICAgICAgICAgICBub2RlLnJhd3Muc3NzQmV0d2VlbiA9IGxhc3RTcGFjZVsxXTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZpcnN0U3BhY2VzKHRva2Vucykge1xuICAgICAgICBsZXQgcmVzdWx0ID0gJyc7XG4gICAgICAgIGZvciAoIGxldCBpID0gMDsgaSA8IHRva2Vucy5sZW5ndGg7IGkrKyApIHtcbiAgICAgICAgICAgIGlmICggdG9rZW5zW2ldWzBdID09PSAnc3BhY2UnIHx8IHRva2Vuc1tpXVswXSA9PT0gJ25ld2xpbmUnICkge1xuICAgICAgICAgICAgICAgIHJlc3VsdCArPSB0b2tlbnMuc2hpZnQoKVsxXTtcbiAgICAgICAgICAgICAgICBpIC09IDE7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgcmF3KG5vZGUsIHByb3AsIHRva2VucywgYWx0TGFzdCkge1xuICAgICAgICBsZXQgdG9rZW4sIHR5cGU7XG4gICAgICAgIGxldCBsZW5ndGggPSB0b2tlbnMubGVuZ3RoO1xuICAgICAgICBsZXQgdmFsdWUgID0gJyc7XG4gICAgICAgIGxldCBjbGVhbiAgPSB0cnVlO1xuICAgICAgICBmb3IgKCBsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkgKz0gMSApIHtcbiAgICAgICAgICAgIHRva2VuID0gdG9rZW5zW2ldO1xuICAgICAgICAgICAgdHlwZSAgPSB0b2tlblswXTtcbiAgICAgICAgICAgIGlmICggdHlwZSA9PT0gJ2NvbW1lbnQnIHx8IHR5cGUgPT09ICdzcGFjZScgJiYgaSA9PT0gbGVuZ3RoIC0gMSApIHtcbiAgICAgICAgICAgICAgICBjbGVhbiA9IGZhbHNlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSArPSB0b2tlblsxXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoICFjbGVhbiApIHtcbiAgICAgICAgICAgIGxldCBzc3MgPSB0b2tlbnMucmVkdWNlKCAoYWxsLCBpKSA9PiBhbGwgKyBpWzFdLCAnJyk7XG4gICAgICAgICAgICBsZXQgcmF3ID0gdG9rZW5zLnJlZHVjZSggKGFsbCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICggaVswXSA9PT0gJ2NvbW1lbnQnICYmIGlbNl0gPT09ICdpbmxpbmUnICkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWxsICsgJy8qICcgKyBpWzFdLnNsaWNlKDIpLnRyaW0oKSArICcgKi8nO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhbGwgKyBpWzFdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sICcnKTtcbiAgICAgICAgICAgIG5vZGUucmF3c1twcm9wXSA9IHsgdmFsdWUsIHJhdyB9O1xuICAgICAgICAgICAgaWYgKCBzc3MgIT09IHJhdyApIG5vZGUucmF3c1twcm9wXS5zc3MgPSBzc3M7XG4gICAgICAgIH1cbiAgICAgICAgbm9kZVtwcm9wXSA9IHZhbHVlO1xuXG4gICAgICAgIGxldCBsYXN0ID0gdG9rZW5zW3Rva2Vucy5sZW5ndGggLSAxXSB8fCBhbHRMYXN0O1xuICAgICAgICBub2RlLnNvdXJjZS5lbmQgPSB7XG4gICAgICAgICAgICBsaW5lOiAgIGxhc3RbNF0gfHwgbGFzdFsyXSxcbiAgICAgICAgICAgIGNvbHVtbjogbGFzdFs1XSB8fCBsYXN0WzNdXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgbmV4dE5vbkNvbW1lbnQocG9zKSB7XG4gICAgICAgIGxldCBuZXh0ID0gcG9zO1xuICAgICAgICBsZXQgcGFydDtcbiAgICAgICAgd2hpbGUgKCBuZXh0IDwgdGhpcy5wYXJ0cy5sZW5ndGggKSB7XG4gICAgICAgICAgICBuZXh0ICs9IDE7XG4gICAgICAgICAgICBwYXJ0ID0gdGhpcy5wYXJ0c1tuZXh0XTtcbiAgICAgICAgICAgIGlmICggcGFydC5lbmQgfHwgIXBhcnQuY29tbWVudCApIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwYXJ0O1xuICAgIH1cblxuICAgIGNvbW1lbnRUZXh0KG5vZGUsIHRva2VuKSB7XG4gICAgICAgIGxldCB0ZXh0ID0gdG9rZW5bMV07XG4gICAgICAgIGlmICggdG9rZW5bNl0gPT09ICdpbmxpbmUnICkge1xuICAgICAgICAgICAgbm9kZS5yYXdzLmlubGluZSA9IHRydWU7XG4gICAgICAgICAgICB0ZXh0ID0gdGV4dC5zbGljZSgyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRleHQgPSB0ZXh0LnNsaWNlKDIsIC0yKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBtYXRjaCA9IHRleHQubWF0Y2goL14oXFxzKikoW15dKlteXFxzXSkoXFxzKilcXG4/JC8pO1xuICAgICAgICBpZiAoIG1hdGNoICkge1xuICAgICAgICAgICAgbm9kZS50ZXh0ID0gbWF0Y2hbMl07XG4gICAgICAgICAgICBub2RlLnJhd3MubGVmdCA9IG1hdGNoWzFdO1xuICAgICAgICAgICAgbm9kZS5yYXdzLmlubGluZVJpZ2h0ID0gbWF0Y2hbM107XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBub2RlLnRleHQgPSAnJztcbiAgICAgICAgICAgIG5vZGUucmF3cy5sZWZ0ID0gJyc7XG4gICAgICAgICAgICBub2RlLnJhd3MuaW5saW5lUmlnaHQgPSAnJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIEVycm9yc1xuXG4gICAgZXJyb3IobXNnLCBsaW5lLCBjb2x1bW4pIHtcbiAgICAgICAgdGhyb3cgdGhpcy5pbnB1dC5lcnJvcihtc2csIGxpbmUsIGNvbHVtbik7XG4gICAgfVxuXG4gICAgdW5uYW1lZEF0cnVsZSh0b2tlbikge1xuICAgICAgICB0aGlzLmVycm9yKCdBdC1ydWxlIHdpdGhvdXQgbmFtZScsIHRva2VuWzJdLCB0b2tlblszXSk7XG4gICAgfVxuXG4gICAgdW5uYW1lZERlY2wodG9rZW4pIHtcbiAgICAgICAgdGhpcy5lcnJvcignRGVjbGFyYXRpb24gd2l0aG91dCBuYW1lJywgdG9rZW5bMl0sIHRva2VuWzNdKTtcbiAgICB9XG5cbiAgICBpbmRlbnRlZEZpcnN0TGluZShwYXJ0KSB7XG4gICAgICAgIHRoaXMuZXJyb3IoJ0ZpcnN0IGxpbmUgc2hvdWxkIG5vdCBoYXZlIGluZGVudCcsIHBhcnQubnVtYmVyLCAxKTtcbiAgICB9XG5cbiAgICB3cm9uZ0luZGVudChleHBlY3RlZCwgcmVhbCwgcGFydCkge1xuICAgICAgICBsZXQgbXNnID0gYEV4cGVjdGVkICR7IGV4cGVjdGVkIH0gaW5kZW50LCBidXQgZ2V0ICR7IHJlYWwgfWA7XG4gICAgICAgIHRoaXMuZXJyb3IobXNnLCBwYXJ0Lm51bWJlciwgMSk7XG4gICAgfVxuXG4gICAgYmFkUHJvcCh0b2tlbikge1xuICAgICAgICB0aGlzLmVycm9yKCdVbmV4cGVjdGVkIHNlcGFyYXRvciBpbiBwcm9wZXJ0eScsIHRva2VuWzJdLCB0b2tlblszXSk7XG4gICAgfVxuXG59XG4iXX0=