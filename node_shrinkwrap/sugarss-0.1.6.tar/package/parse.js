'use strict';

exports.__esModule = true;
exports.default = parse;

var _input = require('postcss/lib/input');

var _input2 = _interopRequireDefault(_input);

var _preprocess = require('./preprocess');

var _preprocess2 = _interopRequireDefault(_preprocess);

var _tokenize = require('./tokenize');

var _tokenize2 = _interopRequireDefault(_tokenize);

var _parser = require('./parser');

var _parser2 = _interopRequireDefault(_parser);

var _liner = require('./liner');

var _liner2 = _interopRequireDefault(_liner);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function parse(source, opts) {
    var input = new _input2.default(source, opts);

    var parser = new _parser2.default(input);
    parser.parts = (0, _preprocess2.default)(input, (0, _liner2.default)((0, _tokenize2.default)(input)));
    parser.loop();

    return parser.root;
}
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhcnNlLmVzNiJdLCJuYW1lcyI6WyJwYXJzZSIsInNvdXJjZSIsIm9wdHMiLCJpbnB1dCIsInBhcnNlciIsInBhcnRzIiwibG9vcCIsInJvb3QiXSwibWFwcGluZ3MiOiI7OztrQkFPd0JBLEs7O0FBUHhCOzs7O0FBRUE7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7OztBQUVlLFNBQVNBLEtBQVQsQ0FBZUMsTUFBZixFQUF1QkMsSUFBdkIsRUFBNkI7QUFDeEMsUUFBSUMsUUFBUSxvQkFBVUYsTUFBVixFQUFrQkMsSUFBbEIsQ0FBWjs7QUFFQSxRQUFJRSxTQUFTLHFCQUFXRCxLQUFYLENBQWI7QUFDQUMsV0FBT0MsS0FBUCxHQUFlLDBCQUFXRixLQUFYLEVBQWtCLHFCQUFNLHdCQUFVQSxLQUFWLENBQU4sQ0FBbEIsQ0FBZjtBQUNBQyxXQUFPRSxJQUFQOztBQUVBLFdBQU9GLE9BQU9HLElBQWQ7QUFDSCIsImZpbGUiOiJwYXJzZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBJbnB1dCBmcm9tICdwb3N0Y3NzL2xpYi9pbnB1dCc7XG5cbmltcG9ydCBwcmVwcm9jZXNzIGZyb20gJy4vcHJlcHJvY2Vzcyc7XG5pbXBvcnQgdG9rZW5pemVyICBmcm9tICcuL3Rva2VuaXplJztcbmltcG9ydCBQYXJzZXIgICAgIGZyb20gJy4vcGFyc2VyJztcbmltcG9ydCBsaW5lciAgICAgIGZyb20gJy4vbGluZXInO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBwYXJzZShzb3VyY2UsIG9wdHMpIHtcbiAgICBsZXQgaW5wdXQgPSBuZXcgSW5wdXQoc291cmNlLCBvcHRzKTtcblxuICAgIGxldCBwYXJzZXIgPSBuZXcgUGFyc2VyKGlucHV0KTtcbiAgICBwYXJzZXIucGFydHMgPSBwcmVwcm9jZXNzKGlucHV0LCBsaW5lcih0b2tlbml6ZXIoaW5wdXQpKSk7XG4gICAgcGFyc2VyLmxvb3AoKTtcblxuICAgIHJldHVybiBwYXJzZXIucm9vdDtcbn1cbiJdfQ==